# Owner & Inventor: Charles Kendrick
# This technology and code are the intellectual property of Charles Kendrick.
# Date: December 21, 2025

